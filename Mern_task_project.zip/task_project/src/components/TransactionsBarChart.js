// TransactionsBarChart.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Chart } from 'react-chartjs-2';

const TransactionsBarChart = () => {
    const [selectedMonth, setSelectedMonth] = useState('March');
    const [barChartData, setBarChartData] = useState([]);

    useEffect(() => {
        // Fetch bar chart data for the selected month from API
        axios.get(`http://localhost:5000/api/transactions/bar-chart`)
            .then(response => {setBarChartData(response.data); console.log(response.data)})
            .catch(error => console.error('Error fetching bar chart data:', error));
    }, [selectedMonth]);

    // Extract labels and data for the chart
    const labels = barChartData.map(item => item._id);

    const data = barChartData.map(item => item.count);
    console.log(labels);
    console.log(data);

    const chartData = {
        labels: labels,
        datasets: [
            {
                label: 'Items count',
                data: data,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
            },
        ],
    };

    return (
        <div>
            <h2>Bar Chart - {selectedMonth}</h2>
            <Chart.Bar data={chartData} />
        </div>
    );
};

export default TransactionsBarChart;

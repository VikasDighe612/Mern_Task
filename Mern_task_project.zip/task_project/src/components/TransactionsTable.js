// TransctionsTable.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './TransactionsTable.css';

const TransactionsTable = () => {
    const [transactions, setTransactions] = useState([]);
    const [searchText, setSearchText] = useState('');
    const [currentPage, setCurrentPage] = useState(1);

    useEffect(() => {
        // Fetch transactions from API based on search text and pagination
        axios.get(`http://localhost:5000/api/transactions?searchText=${searchText}&page=${currentPage}`)
            .then(response => {setTransactions(response.data); console.log(response.data)})
            .catch(error => console.error('Error fetching transactions:', error));
    }, [searchText, currentPage]);

    // Pagination functions
    const nextPage = () => setCurrentPage(prevPage => prevPage + 1);
    const prevPage = () => setCurrentPage(prevPage => Math.max(prevPage - 1, 1));

    return (
        <div>
            <input
                type="text"
                value={searchText}
                onChange={e => setSearchText(e.target.value)}
                placeholder="Search transaction"
            />
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Date of Sale</th>
                        <th>Sold</th>
                        <th>Image</th>
                    </tr>
                </thead>
                <tbody>
                    {transactions.map(transaction => (
                        <tr key={transaction._id}>
                            <td>{transaction.id}</td>
                            <td>{transaction.title}</td>
                            <td>{transaction.description}</td>
                            <td>{transaction.price}</td>
                            <td>{transaction.dateOfSale}</td>
                            <td>{transaction.sold ? 'Yes' : 'No'}</td>
                            <td>
                                {transaction.image && (
                                    <img src={transaction.image} alt={transaction.title} />
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <div>
                <button onClick={prevPage}>Previous</button>
                <span>Page {currentPage}</span>
                <button onClick={nextPage}>Next</button>
            </div>
        </div>
    );
};

export default TransactionsTable;

// TransactionsDashboard.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './TransactionsDashboard.css';

const TransactionsDashboard = () => {
   // const [selectedMonth, setSelectedMonth] = useState('March');
const [statistics, setStatistics] = useState({
totalNotSoldItems:"",
totalSaleAmount:[],
totalSoldItems:""

});

    useEffect(() => {
        // Fetch statistics for the selected month from API
        axios.get(`http://localhost:5000/api/transactions/statistics`)
            .then(response => {
                setStatistics({
                    totalNotSoldItems:response.data.totalNotSoldItems,
                    totalSaleAmount:response.data.totalSaleAmount,
                    totalSoldItems:response.data.totalSoldItems
                }); 
                console.log(response.data)
                console.log(statistics);
            
            })
            .catch(error => console.error('Error fetching statistics:', error));
    }, []);

  
    return (
        <div className="dashboard-container">
            <div className="statistics-section">
                <h2>Statistics</h2>
                <div className="total-sale-amount">
                    {statistics.totalSaleAmount && (
                        <div>
                            {statistics.totalSaleAmount.map(data => (
                                <div key={data._id}>
                                    <h5>Total sale amount : {data.totalAmount}</h5>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
                <div className="total-sold-items">

                    <h5>Total number of sold items : {statistics.totalSoldItems}</h5>
                
                </div>
                <div className="total-not-sold-items">
                    <h5>Total number of not sold items : {statistics.totalNotSoldItems}</h5>
                </div>
            </div>
        </div>
    );
};

export default TransactionsDashboard;

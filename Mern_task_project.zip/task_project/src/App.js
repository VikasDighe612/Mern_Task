import React from 'react';
import './App.css';
import TransactionsTable from '../src/components/TransactionsTable';
import TransactionsDashboard from './components/TransactionsDashboard';
import TransactionsBarChart from './components/TransactionsBarChart';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Transactions Management</h1>
        <TransactionsDashboard />
        <TransactionsTable />
        {/* <TransactionsBarChart /> */}
      </header>
    </div>
  );
}

export default App;

// routes/transactions.js
const fetch=require('node-fetch-commonjs');
const express = require('express');
const router = express.Router();
const Transaction = require('./models/Transaction');

// Initialize Database API

async function fetchThirdPartyData(){
    const data=await fetch('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    const response=await data.json();
    //console.log(response);
    return response;
}

async function hello(){
    try {
        // Fetch data from third-party API
        const data = await fetchThirdPartyData();
        // Insert data into MongoDB
        await Transaction.insertMany(data);

    } catch (error) {
       console.log(error)
    }
}

hello();

// List Transactions API
router.get('/', async (req, res) => {
    try {
        // Implement pagination and search functionality here
        // Example:
        const transactions = await Transaction.find().limit(10);
        console.log(transactions[0].dateOfSale.getMonth())
        res.status(200).json(transactions);
    } catch (error) {
        res.status(500).json({ message: 'Internal server error', error: error });
    }
});

// Statistics API
router.get('/statistics', async (req, res) => {
    try {
        // Calculate statistics for selected month
        // Example:
        const totalSaleAmount = await Transaction.aggregate([
            { $match: { /* Filter transactions by selected month */ } },
            { $group: { _id: null, totalAmount: { $sum: '$price' } } }
        ]);

        const totalSoldItems = await Transaction.countDocuments({ /* Filter sold items by selected month */ });

        const totalNotSoldItems = await Transaction.countDocuments({ /* Filter unsold items by selected month */ });

        res.status(200).json({ totalSaleAmount, totalSoldItems, totalNotSoldItems });
    } catch (error) {
        res.status(500).json({ message: 'Internal server error', error: error });
    }
});

// Bar Chart API
router.get('/bar-chart', async (req, res) => {
    try {
        // Generate data for bar chart
        // Example:
        const barChartData = await Transaction.aggregate([
            { $match: { dateOfSale:Date("2021-10-27T14:59:54.000+00:00")} },
            {
                $group: {
                    _id: { $concat: [{$toString: {$divide: ['$price', 100]}}, '-', {$toString: {$divide: ['$price', 100] + 1}}] },
                    count: { $sum: 1 }
                }
            }
        ]);

        res.status(200).json(barChartData);
    } catch (error) {
        res.status(500).json({ message: 'Internal server error', error: error });
    }
});

// Pie Chart API
router.get('/pie-chart', async (req, res) => {
    try {
        // Generate data for pie chart
        // Example:
        const pieChartData = await Transaction.aggregate([
            { $match: { /* Filter transactions by selected month */ } },
            { $group: { _id: '$category', count: { $sum: 1 } } }
        ]);

        res.status(200).json(pieChartData);
    } catch (error) {
        res.status(500).json({ message: 'Internal server error', error: error });
    }
});
console.log("hi");
module.exports = router;

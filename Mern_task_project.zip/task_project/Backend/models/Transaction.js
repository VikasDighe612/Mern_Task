// models/Transaction.js

const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
    id:{type:Number},
    image:{type:String},
    category:{type:String},
    dateOfSale: { type: Date},
    title: { type: String},
    description: { type: String},
    price: { type: Number},
    sold: { type: Boolean}
});

module.exports = mongoose.model('Transaction', transactionSchema);

// server.js

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const transactionsRouter = require('./transactions');

const app = express();
const PORT = process.env.PORT || 5000;
const MONGODB_URI = 'mongodb://0.0.0.0:27017/transactionsDB';

// Middleware
app.use(cors({
    origin:"*"
}));
app.use(bodyParser.json());
app.use(express.json());
// Routes
app.use('/api/transactions', transactionsRouter);

// Database connection
mongoose.connect(MONGODB_URI, { useNewUrlParser: true })
    .then(() => {
        console.log('Connected to MongoDB');
        // Start server
        app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));
    })
    .catch(err => console.error('Error connecting to MongoDB:', err));

    app.get("/",(req, res)=>{
        res.json("server is running");
    })
